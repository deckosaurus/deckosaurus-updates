> **This app's copy, 2026-09-10 (feature 601 Phase 5f).** The provenance, the
> licence findings and the pending owner decisions below are unchanged from where
> they were recorded (feature 601 Phase 0). Only the "Used at" pointers were
> re-resolved against this repo's layout: the product records now live in DeckKit
> and the chat surfaces under `Sources/DeckosaurusCore/Chat/`. `BrandIcon` itself
> is `Sources/DeckosaurusCore/Shared/BrandIcon.swift`.

# Brand marks in `Glyphs/`

Recorded by feature 601, Phase 0 (2026-09-07). **Licences cover copyright; these
files depict trademarks, which copyright licences do not grant rights to.** This
file records provenance, the owner's published usage guidelines, and where each
mark appears in the app so the trademark decision can be made per mark rather
than in bulk.

## What is in this directory

Eight SVGs originally; `brand-openai.svg` and `brand-antigravity.svg` are removed (feature 550 R3
— see their rows below), leaving six. Three are open-licensed icons and need no decision:

| File | Licence | Source |
|---|---|---|
| `lucide-brain.svg` | ISC | [Lucide](https://lucide.dev) — Copyright (c) for portions 2020 Lucide Contributors; portions 2013–2022 Cole Bemis (Feather Icons) |
| `lucide-dices.svg` | ISC | Lucide |
| `lucide-git-branch.svg` | ISC | Lucide |

The other five (two now removed, see below) are third-party **brand marks** and are the subject of
this file.

## Shared provenance signal

Four of the five files (`brand-anthropic`, `brand-claude`, `brand-openai`,
`brand-snowflake` — the last three since removed) are byte-for-byte in the [Simple
Icons](https://simpleicons.org) output shape: a single-line
`<svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">` with a
`<title>` element and one monochrome `<path>`, no `fill`, no comment header.
None of the files carries an in-file attribution comment, so this is inferred
from the format, not stated by the file.

**Simple Icons licences its SVG path data CC0-1.0 but states explicitly that the
marks themselves remain the trademarks of their owners** and that use is subject
to each owner's brand guidelines. So the copyright question is settled (CC0) and
the trademark question is not — which is exactly what the per-mark rows below
are for.

`brand-antigravity.svg` is different: the source is named in code (see its row).

## The five marks (three live, two removed)

### `brand-anthropic.svg`

- **Depicts:** the Anthropic wordmark glyph. `<title>Anthropic</title>`.
- **Probable source:** Simple Icons (`anthropic`) — CC0 path data.
- **Trademark owner:** Anthropic PBC.
- **Guidelines:** <https://www.anthropic.com/legal/brand-guidelines> (also
  <https://www.anthropic.com/trademark-policy> for the mark-usage policy).
- **Used at:** `ClaudeCodeProduct.companyAssetName` (DeckKit)
  — `companyAssetName`. Rendered by the shared `BrandIcon` view, which reaches
  the user in: Preferences ▸ Coding Agents (the product subsection header and
  its icon-style picker), the New Workspace dialog, agent chat session headers
  and welcome cards, and the tasks row icon.
- **Owner decision: pending.**

### `brand-claude.svg`

- **Depicts:** the Claude "sunburst" product mark. `<title>Claude</title>`.
- **Probable source:** Simple Icons (`claude`) — CC0 path data.
- **Trademark owner:** Anthropic PBC.
- **Guidelines:** <https://www.anthropic.com/legal/brand-guidelines> ·
  <https://www.anthropic.com/trademark-policy>
- **Used at:** `ClaudeCodeProduct.productAssetName` (DeckKit)
  — `productAssetName` (Claude Code is the default agent, so this is the most
  frequently rendered of the five). Same `BrandIcon` surfaces as above.
- **Owner decision: pending.**

### `brand-openai.svg` — REMOVED (feature 550 R3)

Deleted from this app's `Resources/Glyphs/` when Codex was cut from release 1.
`OpenAICodexProduct.companyAssetName` (DeckKit) still names this asset — the
library is unaffected — but `CodingAgentAvailability` (550 R3) means no live
call site in this app ever renders a Codex product's `BrandIcon` any more, so
the file was orphaned. `AssetGlyph.loadTemplate` degrades to a generic SF
Symbol on a missing asset, so this is not a crash risk if that ever changes.
No trademark decision was reached before removal; the row above is history,
not a live provenance record.

### `brand-snowflake.svg` — REMOVED (feature 550 R4)

Deleted from this app's `Resources/Glyphs/` when Cortex Code was cut from release 1, same
reasoning as `brand-openai.svg` above. `CortexCodeProduct.companyAssetName` (DeckKit) still names
this asset — the library is unaffected — but `CodingAgentAvailability` is an allow-list of one, so
nothing in this app renders a Cortex product's `BrandIcon` any more and the file was orphaned.
`AssetGlyph.loadTemplate` degrades to a generic SF Symbol on a missing asset, so this is not a
crash risk if that ever changes. It depicted the Snowflake corporate mark (Simple Icons CC0 path
data; trademark owner Snowflake Inc.); no owner decision was reached before removal, and this row
is history, not a live provenance record.

### `brand-antigravity.svg` — REMOVED (feature 550 R3)

Deleted from this app's `Resources/Glyphs/` when Antigravity was cut from release 1, same
reasoning as `brand-openai.svg` above. `AntigravityProduct.companyAssetName` (DeckKit) still names
this asset — the library is unaffected — but nothing in this app renders an Antigravity product's
`BrandIcon` any more. This was the highest-trademark-exposure mark of the five (a traced derivative
of an official Google press-kit asset, per `AntigravityProduct.swift`'s own doc comment, not a
Simple Icons CC0 path), so its removal also closes that open exposure. No owner decision was
reached before removal.

## Context for the decision

Every mark is used **nominatively** — to identify which third-party coding agent
a session, workspace, or preference row belongs to. None is used as this
project's own logo, in its app icon, in marketing, or in a way suggesting
endorsement. Nominative use is the usual footing for this pattern, but it is the
owner's call per mark and per jurisdiction.

If a mark fails the check, the fallback already exists in code and costs nothing:
`CodingAgentProduct.resolvedBrandAssetName(for:)` returns `nil` for the
`.sparkle` / `.cpu` styles, and `defaultBrandIconStyle` degrades to `.sparkle`
whenever a product ships no asset. Deleting the SVG and dropping the
`companyAssetName` / `productAssetName` override is sufficient — the SF Symbol
named by `brandIconSystemName` renders in its place with no layout change. The
feature 601 plan records this as the Phase 5 remedy (replace with a text label or
symbol rather than ship the mark).
