#!/bin/zsh
# deck-saver — lean Horizon deck-terminal screensaver. Same pipe look as
# codeck-screensaver at a fraction of the cost, purpose-built for running in
# 100 prewarmed terminals at once.
#
# Where the savings come from (vs codeck-screensaver):
#   • zsh + `zselect` — the per-frame delay AND the keypoll are ONE builtin that
#     select()s on the pty. NO `/bin/sleep` fork per frame (the original's
#     dominant cost: ~fps × N-terminals process spawns/sec). Measured ~0 CPU
#     while idling between frames.
#   • the header/footer is drawn ONCE and only on resize — not every frame —
#     so per-frame output is just the moving pipe cells (less VT to parse).
#   • all the non-screensaver machinery is gone: no quote files / `date` /
#     `awk` / markdown / notifications / menu / speed-adjust / test-pattern.
#
# Press q to quit to an interactive shell.

emulate -L zsh
setopt ksharrays            # 0-indexed, bash-like arrays so the pipe maths is plain
zmodload zsh/zselect 2>/dev/null && HAVE_ZSELECT=1 || HAVE_ZSELECT=0
zmodload zsh/system  2>/dev/null && HAVE_SYSTEM=1  || HAVE_SYSTEM=0   # sysread: grab injected cmds in one read

WS_NAME="${WORKSPACE_NAME:-workspace}"
WS_PATH="${WORKSPACE_PATH:-$HOME}"
WS_COLOR="${WORKSPACE_COLOR:-#4A90D9}"
CODECK_SPEED="${CODECK_SPEED:-0.5}"
COUNTDOWN="${CODECK_COUNTDOWN:-0}"
SPLASH_MS="${CODECK_SPLASH_MS:-400}"
# Optional control file the app rewrites to RETUNE us live (e.g. `speed=0.25`).
# Polled on the resize-poll cadence; a general one-command-per-line channel we can
# extend later (e.g. `notify=...`). Read fork-free via a redirect — no `cat`.
CODECK_CTRL="${CODECK_CTRL:-}"

# (Re)derive the frame interval + poll cadence from CODECK_SPEED. Factored out so a
# live `speed=` from the control file can recompute everything mid-run.
#   • TICK_CS — zselect timeout in CENTISECONDS; codeck-screensaver cadence is
#     0.04s/speed = (4/speed) cs, floored at 1cs.
#   • POLL_EVERY — frames between size/control polls, sized to ~0.3s REGARDLESS of
#     fps so a slow speed doesn't make resize laggy. = 30cs / frame-period(cs).
recompute_tick() {
    TICK_CS=$(( 4.0 / (CODECK_SPEED > 0 ? CODECK_SPEED : 1) ))
    TICK_CS=${TICK_CS%.*}
    (( TICK_CS < 1 )) && TICK_CS=1
    TICK_SEC="0.$(printf '%02d' $TICK_CS)"   # sleep-fallback only (zselect path never uses it)
    POLL_EVERY=$(( 30 / TICK_CS )); (( POLL_EVERY < 1 )) && POLL_EVERY=1
    # Frames of normal pipe animation between word reveals. Sized in seconds so a
    # speed change keeps the cadence roughly constant. = secs*100cs / frame-period(cs).
    WORD_EVERY=$(( ${CODECK_WORD_EVERY_SEC:-14} * 100 / TICK_CS )); (( WORD_EVERY < 1 )) && WORD_EVERY=1
}
recompute_tick

# Apply ONE `key=value` control command — from EITHER channel:
#   • the control file (global broadcast, polled): currently `speed=`
#   • PTY injection (per-terminal, see drain_input): currently `notify=`
# New commands slot in here once and both channels get them.
apply_ctrl_line() {
    case "$1" in
        speed=*)
            local v="${1#speed=}"
            [[ -n "$v" && "$v" != "$CODECK_SPEED" ]] || return
            CODECK_SPEED="$v"
            recompute_tick
            ;;
        notify=*)
            show_notify "${1#notify=}"
            ;;
    esac
}

# Poll the global control file (fork-free redirect) and apply its first line.
poll_ctrl() {
    [[ -n "$CODECK_CTRL" && -r "$CODECK_CTRL" ]] || return
    local line=""
    read -r line < "$CODECK_CTRL" 2>/dev/null
    [[ -n "$line" ]] && apply_ctrl_line "$line"
}

# ── Notification banner (per-terminal, injected via PTY) ────────────────────────
# A `notify=<msg>` arrives as PTY input; we flash an inverse bar mid-screen for
# ~4s (redrawn each frame so the pipes don't erase it) AND emit OSC 9 so ghostty
# raises a NATIVE desktop notification (when the app is inactive).
_notify_msg=""; _notify_ticks=0
show_notify() {
    local m="$1"; [[ -z "$m" ]] && return
    _notify_msg="$m"
    _notify_ticks=$(( 400 / TICK_CS )); (( _notify_ticks < 1 )) && _notify_ticks=1   # ~4s at any fps
    printf '\033]9;%s\007' "$m"
    draw_notify
}
draw_notify() {
    local m="  ${_notify_msg}  "
    local x=$(( (COLS - ${#m}) / 2 + 1 )); (( x < 1 )) && x=1
    printf '\033[%d;%dH\033[7m%s%s%s\033[27m%s' "$(( ROWS / 2 ))" "$x" "$BOLD" "$C3" "$m" "$RS"
}
clear_notify() { printf '\033[%d;1H\033[K' "$(( ROWS / 2 ))"; _notify_msg="" }

# ── Colour: parse hex → bright / dark(55%) / light(55%) shades ──────────────────
_hex="${WS_COLOR#\#}"
_R=$(( 16#${_hex:0:2} )); _G=$(( 16#${_hex:2:2} )); _B=$(( 16#${_hex:4:2} ))
_Rd=$(( _R * 55 / 100 ));            _Gd=$(( _G * 55 / 100 ));            _Bd=$(( _B * 55 / 100 ))
_Rl=$(( _R + (255 - _R) * 55 / 100 )); _Gl=$(( _G + (255 - _G) * 55 / 100 )); _Bl=$(( _B + (255 - _B) * 55 / 100 ))
C1=$'\033['"38;2;${_R};${_G};${_B}m"
C2=$'\033['"38;2;${_Rd};${_Gd};${_Bd}m"
C3=$'\033['"38;2;${_Rl};${_Gl};${_Bl}m"
RS=$'\033[0m'; BOLD=$'\033[1m'; DIM=$'\033[2m'

get_size() {
    local sz; sz=$(stty size 2>/dev/null)
    [[ -n "$sz" ]] && { ROWS=${sz%% *}; COLS=${sz##* }; }
    (( ${COLS:-0} <= 0 )) && COLS=80
    (( ${ROWS:-0} <= 0 )) && ROWS=24
}

# Resize detection. The WINCH trap is UNRELIABLE while we're blocked in the
# fork-free frame-wait (zselect/read -t restart on EINTR and lose the signal —
# verified 1/5 delivered, vs 5/5 for a forked `sleep`). So we do NOT depend on
# the signal: we POLL the real size every POLL_EVERY frames and flag a change.
# `stty` is a fork, but amortized to one per POLL_EVERY frames (POLL_EVERY is set
# above to keep that ~every 0.3s). The trap just sets `_winch` as an early-trigger
# hint so the occasional delivered signal still reacts instantly.
maybe_resize() {
    local sz; sz=$(stty size 2>/dev/null)
    [[ -z "$sz" ]] && return
    local r=${sz%% *} c=${sz##* }
    [[ "$r" == "$ROWS" && "$c" == "$COLS" ]] && return
    ROWS=$r; COLS=$c; _resized=1
}

cleanup() {
    tput rmcup 2>/dev/null
    printf '\033[?1049l'    # 344 (344.B1) — explicit alt-screen EXIT, terminfo-independent (see smcup note)
    stty sane 2>/dev/null
    # 344 — NO `\e[2J\e[H` here: the saver lives on the ALTERNATE screen now, so exiting it
    # restores the primary screen intact — and that primary screen holds the replayed session
    # history the restore feature just printed. The old clear (needed when the saver drew on
    # the primary screen directly) was ERASING the replay the moment the user pressed q.
    printf '\033[?25h\033[0 q%s' "$RS"
}
trap 'cleanup; exit 0' INT TERM
trap cleanup EXIT
_resized=0; _winch=0; _frame=0
trap '_winch=1' WINCH      # early-trigger hint only — the per-frame poll is the real backstop

# Read whatever PTY input is available (non-blocking) and act on it. The app injects
# per-terminal control lines as `\x1f<key>=<value>\n` (US sentinel = can't be confused
# with the `q` quit key). A bare q/Q (a real keypress) sets `_quit`.
_inbuf=""; _quit=0
drain_input() {
    local chunk=""
    if (( HAVE_SYSTEM )); then sysread -t 0 chunk 2>/dev/null
    else                       read -k 1 -u 0 chunk 2>/dev/null; fi
    [[ -z "$chunk" ]] && return
    _inbuf+="$chunk"
    while [[ "$_inbuf" == *$'\x1f'* ]]; do            # a control line begins at the US sentinel
        local after="${_inbuf#*$'\x1f'}"             # drop bytes up to & incl the US
        [[ "$after" == *$'\n'* ]] || { _inbuf=$'\x1f'"$after"; break; }   # incomplete → wait for the LF
        apply_ctrl_line "${after%%$'\n'*}"           # the command, up to LF
        _inbuf="${after#*$'\n'}"                     # remainder
    done
    # A 'q' only quits when it's NOT inside a still-arriving control line.
    if [[ "$_inbuf" != *$'\x1f'* && "$_inbuf" == *[qQ]* ]]; then _quit=1; _inbuf=""; fi
    (( ${#_inbuf} > 256 )) && _inbuf="${_inbuf: -64}"
}

# Frame delay (no fork) + drain any input. Falls back to sleep only if zsh/zselect
# is somehow unavailable.
frame_wait() {
    if (( HAVE_ZSELECT )); then
        zselect -t $TICK_CS -r 0 2>/dev/null && drain_input
    else
        sleep "$TICK_SEC"
    fi
}

# ── Pipes (identical look to codeck-screensaver) ────────────────────────────────
typeset -a PX PY PD PV
N=0; MAX=12

new_pipe() {
    PX[N]=$(( RANDOM % COLS + 1 ))
    PY[N]=$(( RANDOM % (ROWS - 3) + 3 ))
    PD[N]=$(( RANDOM % 4 ))
    PV[N]=$(( RANDOM % 3 ))
    N=$(( N + 1 ))
}

step_pipe() {
    local i=$1 od=${PD[$1]}
    case ${PV[$i]} in 0) printf '%s' "$C1" ;; 1) printf '%s' "$C2" ;; 2) printf '%s' "$C3" ;; esac
    printf '\033[%d;%dH' "${PY[$i]}" "${PX[$i]}"
    case ${PD[$i]} in 0|2) printf '│' ;; 1|3) printf '─' ;; esac
    case ${PD[$i]} in
        0) PY[$i]=$(( PY[$i] - 1 )) ;;
        1) PX[$i]=$(( PX[$i] + 1 )) ;;
        2) PY[$i]=$(( PY[$i] + 1 )) ;;
        3) PX[$i]=$(( PX[$i] - 1 )) ;;
    esac
    (( PX[$i] < 1 ))    && PX[$i]=$COLS
    (( PX[$i] > COLS )) && PX[$i]=1
    (( PY[$i] < 3 ))    && PY[$i]=$ROWS
    (( PY[$i] > ROWS )) && PY[$i]=3
    if (( RANDOM % 12 == 0 )); then
        local nd=$(( RANDOM % 4 ))
        PD[$i]=$nd
        printf '\033[%d;%dH' "${PY[$i]}" "${PX[$i]}"
        case "${od}${nd}" in
            01|32) printf '└' ;; 03|12) printf '┘' ;;
            21|30) printf '┌' ;; 23|10) printf '┐' ;;
        esac
        (( RANDOM % 4 == 0 )) && PV[$i]=$(( RANDOM % 3 ))
        (( N < MAX )) && (( RANDOM % 6 == 0 )) && new_pipe
    fi
}

# Header (name + path) and footer (resolution) — drawn once + on resize only.
draw_ui() {
    local lbl="  ${WS_NAME}  " sub="  ${WS_PATH}  "
    local lx=$(( (COLS - ${#lbl}) / 2 + 1 )) sx=$(( (COLS - ${#sub}) / 2 + 1 ))
    (( lx < 1 )) && lx=1; (( sx < 1 )) && sx=1
    printf '\033[1;%dH%s%s%s%s' "$lx" "$BOLD" "$C1" "$lbl" "$RS"
    printf '\033[2;%dH%s%s%s'   "$sx" "$C2"          "$sub" "$RS"
    local res="${COLS}x${ROWS}"
    printf '\033[%d;1H%s  q quit%s' "$ROWS" "$C3" "$RS"
    printf '\033[%d;%dH%s%s%s' "$ROWS" "$(( COLS - ${#res} + 1 ))" "$DIM$C2" "$res" "$RS"
}

# Densely populate the grid quickly (no sleeps) — same budget as the original.
flash_fill() {
    local target=$(( COLS * ROWS / 8 ))
    (( target < 60 )) && target=60
    local f=0
    while (( f < target )); do
        (( _resized )) && return
        for (( i=0; i<N; i++ )); do step_pipe "$i"; done
        (( f++ ))
    done
}

# The between-sentence transition. NOT a black wipe — it reads as a burst of pipes
# flooding the screen. flash_fill alone leaves stray cells of the old sentence showing,
# so we blackout FIRST (instant, unseen — no delay before the repaint) to guarantee a
# clean slate, then immediately flash_fill a fresh dense pipe field over it. The eye sees
# only the pipe flash; the new sentence then reveals on top of that field.
blackout_flash() {
    printf '\033[2J\033[H'                          # instant, complete blackout (kills old text)
    N=0; local i; for (( i=0; i<4; i++ )); do new_pipe; done
    flash_fill                                       # dense pipe burst — the visible "flash"
}

# ── Sentence reveal (blends into the pipes) ─────────────────────────────────────
# Every WORD_EVERY frames we lay out a whole sentence from the TOP-LEFT, rendered in
# the SAME single-line box glyphs the pipes use (Calvin S letterforms, ─ │ ┌ ┐ └ ┘ …),
# word-wrapped so a glyph is never split across lines. We freeze a few seconds so it's
# readable, then let the animation resume — the wandering pipes draw straight over it
# and it dissolves back into the field. Then we loop with the next sentence.
WORD_HOLD_MS="${CODECK_WORD_HOLD_MS:-3500}"

typeset -a SENTENCES
if [[ -n "$CODECK_SENTENCE" ]]; then
    SENTENCES=( "$CODECK_SENTENCE" )
else
    # Mixed lengths. The long ones only surface on terminals big enough to hold them
    # (choose_and_layout retries until it finds one that fits without clipping), so a
    # small deck column tends to land on the short lines and a full screen gets the epics.
    SENTENCES=(
        # tiny — the only ones that fit the tall isometric face on a normal terminal
        "GO."
        "SHIP IT."
        "CODE."
        "BUILD."
        "DEPLOY."
        "MERGE IT."
        "REFACTOR."
        "COMMIT."
        "GREEN BUILD."
        "BE KIND."
        # short
        "READY, SET, BUILD & SHIP IT?"
        "FOCUS."
        "HELLO, WORLD."
        "ONE DECK AT A TIME."
        # medium
        "THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG."
        "MOVE FAST, KEEP IT SIMPLE, AND SHIP SOMETHING REAL TODAY."
        "WELCOME TO THE DECK - LET'S MAKE SOMETHING GOOD."
        # long
        "GOOD CODE READS LIKE A CLEAR SENTENCE: SMALL PIECES, HONEST NAMES, AND NO SURPRISES ALONG THE WAY."
        "EVERY DECK STARTS EMPTY AND ENDS FULL OF SMALL DECISIONS - SO CHOOSE WELL AND MOVE STEADILY."
        # very long (large terminals only)
        "A TERMINAL IS JUST A QUIET PLACE TO THINK; THE BEST WORK HAPPENS WHEN THE TOOLS GET OUT OF THE WAY AND LET THE IDEAS FLOW FREELY ACROSS THE SCREEN."
        "WE SHAPE OUR TOOLS AND THEREAFTER OUR TOOLS SHAPE US - SO BUILD THEM SLOWLY, WITH CARE, AND THEY WILL CARRY YOUR BEST THINKING FOR YEARS TO COME."
        # software-dev, positive spin — quips, wordplay, and life-of-a-developer truths
        "SHIP IT, THEN POLISH IT - MOMENTUM BEATS PERFECTION."
        "EVERY BUG YOU FIX MAKES TOMORROW'S YOU A LITTLE SMARTER."
        "REAL PROGRAMMERS COUNT FROM ZERO, AND SO DOES THEIR COFFEE."
        "THERE ARE ONLY TWO HARD THINGS: NAMING, CACHING, AND OFF-BY-ONE ERRORS."
        "COMMIT OFTEN, PUSH BRAVELY, REFACTOR WITHOUT FEAR."
        "A CLEAN FUNCTION IS A LOVE LETTER TO YOUR FUTURE SELF."
        "GREEN TESTS, CALM MIND, HAPPY DEPLOY."
        "DEBUGGING IS BEING A DETECTIVE IN A CRIME WHERE YOU ARE ALSO THE CULPRIT."
        "CODE LIKE NOBODY IS WATCHING; COMMENT LIKE EVERYBODY IS."
        "THE BEST ERROR MESSAGE IS THE ONE THAT NEVER HAS TO APPEAR."
        "SIMPLICITY IS THE ULTIMATE SOPHISTICATION - AND THE ULTIMATE SPEEDUP."
        "REST IS A FEATURE, NOT A BUG - GO TOUCH SOME GRASS."
        "YOU ARE ONE GOOD NIGHT'S SLEEP AWAY FROM SOLVING THAT BUG."
        "MAKE IT WORK, MAKE IT RIGHT, MAKE IT FAST - IN THAT ORDER."
        "SMALL COMMITS, BIG WINS."
        "TALK TO THE RUBBER DUCK; IT NEVER JUDGES YOUR LOGIC."
        "A WILD EDGE CASE APPEARS! AND YOU WERE READY FOR IT."
        "LEGACY CODE IS JUST A LOVE STORY THAT NEEDS A SEQUEL."
        "THE COMPILER IS THE FRIEND WHO IS HONEST TO A FAULT."
        "WRITE THE TEST, WATCH IT FAIL, MAKE IT PASS, TAKE A BOW."
        "COFFEE COMPILES INTO CODE; CODE COMPILES INTO JOY."
        "NAMING THINGS IS HARD, BUT YOU MAKE IT LOOK EASY."
        "EVERY DEPLOY IS A TINY ACT OF COURAGE."
        "KINDNESS IN CODE REVIEW IS A QUIET SUPERPOWER."
        "READ THE DOCS; SOMEONE WROTE THEM JUST FOR YOU."
        "YAK SHAVING TODAY BUILDS THE RAZOR FOR TOMORROW."
        "REFACTOR MERCILESSLY, DELETE JOYFULLY."
        "A MERGE CONFLICT IS TWO GOOD IDEAS MEETING FOR THE FIRST TIME."
        "TRUST THE PROCESS; THE TESTS HAVE YOUR BACK."
        "SLOW IS SMOOTH, AND SMOOTH IS SHIPPABLE."
        "YOUR FUTURE TEAMMATES WILL THANK YOU FOR THAT COMMENT."
        "DONE IS BEAUTIFUL; PERFECT IS A MOVING TARGET."
        "THE BEST CODE IS THE CODE YOU NEVER HAD TO WRITE."
        "CURIOSITY COMPILED - KEEP ASKING WHY."
        "BREAK THE PROBLEM DOWN UNTIL IT CANNOT FIGHT BACK."
        "GOOD ARCHITECTURE IS INVISIBLE UNTIL YOU NEED IT, THEN IT IS A HERO."
        "LEARN ONE NEW THING TODAY AND THE REST GETS EASIER."
        "A PASSING PIPELINE IS THE SOUND OF A GOOD DAY."
        "PAIR UP; TWO HEADS DEBUG FASTER THAN ONE."
        "STARTING IS THE PART THAT MAKES YOU GREAT."
        "TAKE THE SMALL WIN; IT COUNTS."
        "THE STACK TRACE IS A TREASURE MAP, NOT A THREAT."
        "AUTOMATE THE BORING, SAVOR THE CREATIVE."
        "EVERY EXPERT WAS ONCE A BEGINNER WHO KEPT GOING."
        "SHIP SMALL, LEARN FAST, SMILE OFTEN."
        "CACHE INVALIDATION IS HARD, BUT YOU MAKE IT LOOK EFFORTLESS."
        "GIVE THE VARIABLE A NAME IT ACTUALLY DESERVES."
        "A WELL-RESTED DEVELOPER WRITES FEWER BUGS AND BETTER JOKES."
        "THE TERMINAL IS WHERE IDEAS BECOME REAL."
        "KEEP THE FEEDBACK LOOP SHORT AND THE COFFEE WARM."
        "BOLD IDEAS, GENTLE COMMITS."
        "IT COMPILED ON THE FIRST TRY; FRAME THIS MOMENT."
        "THE BEST DEBUGGER IS A GOOD SLEEP AND A FRESH PAIR OF EYES."
        "PROGRESS OVER PERFECTION, ALWAYS."
        "EVERY GREEN CHECKMARK IS A SMALL CELEBRATION."
        "WRITE CODE FOR HUMANS; THE MACHINE WILL COPE."
        "ONE MORE TEST NEVER HURT ANYBODY."
        "DELETING CODE FEELS BETTER THAN WRITING IT, AND THAT IS OKAY."
        "YOU ARE THE SENIOR DEVELOPER SOMEONE IS LOOKING UP TO RIGHT NOW."
        "ASK THE QUESTION; SOMEONE ELSE IS WONDERING TOO."
        "A TIDY REPO IS A TIDY MIND."
        "TURN THE BUG INTO A FEATURE AND TAKE THE CREDIT."
        "GREAT SOFTWARE IS A MARATHON RUN AT A FRIENDLY PACE."
        "CELEBRATE THE MERGE; YOU EARNED IT."
        "THE RUBBER DUCK APPROVES OF YOUR REFACTOR."
        "FIX IT ONCE, DOCUMENT IT FOREVER."
        "CURIOSITY IS THE BEST DEPENDENCY YOU CAN INSTALL."
        "BUILD TOOLS THAT MAKE FUTURE YOU LAZY IN THE BEST WAY."
        "THERE IS NO CLOUD - JUST SOMEONE ELSE'S COMPUTER BEING HELPFUL."
        "KEEP CALM AND CLEAR THE CACHE."
        "THE ONLY BAD QUESTION IS THE ONE LEFT IN YOUR HEAD."
        "YOU SHIPPED SOMETHING TODAY; THAT IS NOT NOTHING."
        "READABLE CODE IS A RANDOM ACT OF KINDNESS."
        "THE BEST FRAMEWORK IS THE ONE YOUR TEAM LOVES."
        "LITTLE BY LITTLE, A LITTLE BECOMES A LOT OF SHIPPED FEATURES."
        "OPTIMISM IS A VALID ENGINEERING STRATEGY."
        "TAKE A WALK; THE ANSWER WILL MEET YOU HALFWAY."
        "A GREEN BUILD AND A WARM CUP - LIFE IS GOOD."
        "BE KIND TO YOUR CODE; IT WILL OUTLIVE YOUR MEMORY OF WRITING IT."
        "TRUST YOUR TESTS, QUESTION YOUR ASSUMPTIONS, SHIP YOUR WORK."
        "EVERY FUNCTION WANTS TO DO ONE THING WELL; HELP IT."
        "THE BEST COMMENT EXPLAINS WHY, NOT WHAT."
        "GIVE YOURSELF PERMISSION TO WRITE THE NAIVE VERSION FIRST."
        "THE MAP IS NOT THE TERRITORY, BUT A GOOD README COMES CLOSE."
        "BATTERIES INCLUDED, CURIOSITY REQUIRED."
        "YOU CAN ALWAYS REFACTOR; YOU CANNOT ALWAYS START."
        "PRAISE IN PUBLIC, DEBUG IN PRIVATE."
        "A ROLLBACK IS A GRACEFUL BOW, NOT A DEFEAT."
        "THE SYNTAX ERROR IS TEMPORARY; THE LESSON IS FOREVER."
        "SMALL FUNCTIONS, BIG SMILES."
        "SLEEP IS THE CHEAPEST PERFORMANCE OPTIMIZATION."
        "YOU ARE ALLOWED TO BE PROUD OF THAT ONE-LINER."
        "KEEP IT SIMPLE, KEEP IT KIND, KEEP IT SHIPPING."
        "TODAY'S SPAGHETTI IS TOMORROW'S TEACHABLE MOMENT."
        "THE BUILD IS GREEN AND SO ARE THE PASTURES AHEAD."
        "WRITE IT DOWN BEFORE THE IDEA LOGS OUT."
        "A GOOD ABSTRACTION IS A PROMISE YOU KEEP."
        "BE THE TEAMMATE YOU WISH YOU HAD."
        "THE SECOND BEST TIME TO WRITE A TEST IS RIGHT NOW."
        "HELLO WORLD WAS JUST THE BEGINNING; LOOK AT YOU NOW."
        "WHEN IN DOUBT, PRINT IT OUT."
        "GO AHEAD - PUSH TO MAIN ON A FRIDAY, YOU REBEL."
        "GREAT CODE IS WRITTEN TWICE: ONCE TO LEARN, ONCE TO KEEP."
        "SAVE OFTEN, PANIC NEVER."
        "THE HAPPIEST PATH IS THE ONE WITH TESTS ALONG IT."
        "YOUR CURIOSITY IS A RENEWABLE RESOURCE - SPEND IT FREELY."
    )
fi

# Sort the pool ascending by length. choose_and_layout then treats it as a monotone list:
# the sentences that fit the current resolution form a prefix, so it can binary-search the
# cutoff and pick only from what fits. (Key each element with a zero-padded length, sort
# lexically = numerically, strip the key. Quotes preserve the spaces in each sentence.)
if (( ${#SENTENCES[@]} > 1 )); then
    _ssort=()
    for _s in "${SENTENCES[@]}"; do _ssort+=( "${(l:5::0:)${#_s}}|$_s" ); done
    _ssort=( "${(o)_ssort[@]}" )
    SENTENCES=( "${_ssort[@]#*|}" )
fi

# 3-row glyph table. Each row of a letter is equal width (trailing spaces matter).
# The 'o'-style dots in Calvin S punctuation are swapped for ▪ so everything stays
# in the single-line box family and dissolves cleanly under the pipes.
typeset -A GT GM GB
GT[A]='┌─┐'; GM[A]='├─┤'; GB[A]='┴ ┴'
GT[B]='┌┐ '; GM[B]='├┴┐'; GB[B]='└─┘'
GT[C]='┌─┐'; GM[C]='│  '; GB[C]='└─┘'
GT[D]='┌┬┐'; GM[D]=' ││'; GB[D]='─┴┘'
GT[E]='┌─┐'; GM[E]='│┤ '; GB[E]='└─┘'
GT[F]='┌─┐'; GM[F]='├┤ '; GB[F]='└  '
GT[G]='┌─┐'; GM[G]='│ ┬'; GB[G]='└─┘'
GT[H]='┬ ┬'; GM[H]='├─┤'; GB[H]='┴ ┴'
GT[I]='┬';   GM[I]='│';   GB[I]='┴'
GT[J]=' ┬';  GM[J]=' │';  GB[J]='└┘'
GT[K]='┬┌─'; GM[K]='├┴┐'; GB[K]='┴ ┴'
GT[L]='┬  '; GM[L]='│  '; GB[L]='┴─┘'
GT[M]='┌┬┐'; GM[M]='│││'; GB[M]='┴ ┴'
GT[N]='┌┐┌'; GM[N]='│││'; GB[N]='┘└┘'
GT[O]='┌─┐'; GM[O]='│ │'; GB[O]='└─┘'
GT[P]='┌─┐'; GM[P]='├─┘'; GB[P]='┴  '
GT[Q]='┌─┐ '; GM[Q]='│─┼┐'; GB[Q]='└─┘└'
GT[R]='┬─┐'; GM[R]='├┬┘'; GB[R]='┴└─'
GT[S]='┌─┐'; GM[S]='└─┐'; GB[S]='└─┘'
GT[T]='┌┬┐'; GM[T]=' │ '; GB[T]=' ┴ '
GT[U]='┬ ┬'; GM[U]='│ │'; GB[U]='└─┘'
GT[V]='┬  ┬'; GM[V]='└┐┌┘'; GB[V]=' └┘ '
GT[W]='┬ ┬'; GM[W]='│││'; GB[W]='└┴┘'
GT[X]='─┐ ┬'; GM[X]='┌┴┬┘'; GB[X]='┴ └─'
GT[Y]='┬ ┬'; GM[Y]='└┬┘'; GB[Y]=' ┴ '
GT[Z]='┌─┐'; GM[Z]='┌─┘'; GB[Z]='└─┘'
# Punctuation — box glyphs where possible, ▪ for dots.
GT['.']=' ';   GM['.']=' ';   GB['.']='▪'
GT[',']=' ';   GM[',']=' ';   GB[',']='┘'
GT['!']='│';   GM['!']='│';   GB['!']='▪'
GT['?']='┌─┐'; GM['?']=' ┌┘'; GB['?']=' ▪ '
GT['-']='   '; GM['-']='───'; GB['-']='   '
GT[':']=' ';   GM[':']='▪';   GB[':']='▪'
GT[';']=' ';   GM[';']='▪';   GB[';']='┘'
GT["'"]='│';   GM["'"]=' ';   GB["'"]=' '
GT['&']=' ┬ '; GM['&']='┌┼─'; GB['&']='└┘ '

# ── Typefaces (variable height) ─────────────────────────────────────────────────
# One global glyph table G keyed by "<font>\x1f<char>", value = the glyph's rows joined
# by newline. FONT_H holds each font's row height. This lets fonts of DIFFERENT heights
# coexist (3-row box faces, 6-row block/slant, 11-row isometric) — the layout engine reads
# GLYPH_H for whichever font is active. single/double are built from the box base above;
# block/slant/iso are pyfiglet-generated tables embedded below.
SEP=$'\x1f'
typeset -A G FONT_H
FONT_H=( single 3 double 3 block 6 slant 6 iso 11 )

_to_double() {
    REPLY="$1"
    REPLY="${REPLY//─/═}"; REPLY="${REPLY//│/║}"
    REPLY="${REPLY//┌/╔}"; REPLY="${REPLY//┐/╗}"; REPLY="${REPLY//└/╚}"; REPLY="${REPLY//┘/╝}"
    REPLY="${REPLY//┬/╦}"; REPLY="${REPLY//┴/╩}"; REPLY="${REPLY//├/╠}"; REPLY="${REPLY//┤/╣}"; REPLY="${REPLY//┼/╬}"
}
# Build the 3-row single/double faces from the box letterforms (GT/GM/GB).
for _c in "${(k)GT[@]}"; do
    G[single$SEP$_c]="${GT[$_c]}"$'\n'"${GM[$_c]}"$'\n'"${GB[$_c]}"
    _to_double "${GT[$_c]}"; _t="$REPLY"; _to_double "${GM[$_c]}"; _m="$REPLY"; _to_double "${GB[$_c]}"; _b="$REPLY"
    G[double$SEP$_c]="$_t"$'\n'"$_m"$'\n'"$_b"
done

# Parse an embedded font block into G. Records are fixed stride: one token line naming the
# char, then exactly h row lines. (A trailing empty line from the heredoc is ignored by the
# i+h<n guard.) No eval / nameref — writes straight into the global G with a composite key.
parse_font() {
    local font=$1 h=$2 data=$3 ch g r
    local -a L=( "${(@f)data}" )
    local n=${#L[@]} i=0
    while (( i + h < n )); do
        case "${L[i]}" in
            SPACE) ch=' ' ;; DOT) ch='.' ;; COMMA) ch=',' ;; BANG) ch='!' ;;
            QUES) ch='?' ;; DASH) ch='-' ;; COLON) ch=':' ;; SEMI) ch=';' ;;
            APOS) ch="'" ;; AMP) ch='&' ;; *) ch="${L[i]}" ;;
        esac
        (( i++ )); g="${L[i]}"; (( i++ ))
        for (( r=1; r<h; r++ )); do g+=$'\n'"${L[i]}"; (( i++ )); done
        G[$font$SEP$ch]="$g"
    done
}
IFS= read -r -d "" _FD <<'FONTEOF'
A
 █████╗ 
██╔══██╗
███████║
██╔══██║
██║  ██║
╚═╝  ╚═╝
B
██████╗ 
██╔══██╗
██████╔╝
██╔══██╗
██████╔╝
╚═════╝ 
C
 ██████╗
██╔════╝
██║     
██║     
╚██████╗
 ╚═════╝
D
██████╗ 
██╔══██╗
██║  ██║
██║  ██║
██████╔╝
╚═════╝ 
E
███████╗
██╔════╝
█████╗  
██╔══╝  
███████╗
╚══════╝
F
███████╗
██╔════╝
█████╗  
██╔══╝  
██║     
╚═╝     
G
 ██████╗ 
██╔════╝ 
██║  ███╗
██║   ██║
╚██████╔╝
 ╚═════╝ 
H
██╗  ██╗
██║  ██║
███████║
██╔══██║
██║  ██║
╚═╝  ╚═╝
I
██╗
██║
██║
██║
██║
╚═╝
J
     ██╗
     ██║
     ██║
██   ██║
╚█████╔╝
 ╚════╝ 
K
██╗  ██╗
██║ ██╔╝
█████╔╝ 
██╔═██╗ 
██║  ██╗
╚═╝  ╚═╝
L
██╗     
██║     
██║     
██║     
███████╗
╚══════╝
M
███╗   ███╗
████╗ ████║
██╔████╔██║
██║╚██╔╝██║
██║ ╚═╝ ██║
╚═╝     ╚═╝
N
███╗   ██╗
████╗  ██║
██╔██╗ ██║
██║╚██╗██║
██║ ╚████║
╚═╝  ╚═══╝
O
 ██████╗ 
██╔═══██╗
██║   ██║
██║   ██║
╚██████╔╝
 ╚═════╝ 
P
██████╗ 
██╔══██╗
██████╔╝
██╔═══╝ 
██║     
╚═╝     
Q
 ██████╗ 
██╔═══██╗
██║   ██║
██║▄▄ ██║
╚██████╔╝
 ╚══▀▀═╝ 
R
██████╗ 
██╔══██╗
██████╔╝
██╔══██╗
██║  ██║
╚═╝  ╚═╝
S
███████╗
██╔════╝
███████╗
╚════██║
███████║
╚══════╝
T
████████╗
╚══██╔══╝
   ██║   
   ██║   
   ██║   
   ╚═╝   
U
██╗   ██╗
██║   ██║
██║   ██║
██║   ██║
╚██████╔╝
 ╚═════╝ 
V
██╗   ██╗
██║   ██║
██║   ██║
╚██╗ ██╔╝
 ╚████╔╝ 
  ╚═══╝  
W
██╗    ██╗
██║    ██║
██║ █╗ ██║
██║███╗██║
╚███╔███╔╝
 ╚══╝╚══╝ 
X
██╗  ██╗
╚██╗██╔╝
 ╚███╔╝ 
 ██╔██╗ 
██╔╝ ██╗
╚═╝  ╚═╝
Y
██╗   ██╗
╚██╗ ██╔╝
 ╚████╔╝ 
  ╚██╔╝  
   ██║   
   ╚═╝   
Z
███████╗
╚══███╔╝
  ███╔╝ 
 ███╔╝  
███████╗
╚══════╝
0
 ██████╗ 
██╔═████╗
██║██╔██║
████╔╝██║
╚██████╔╝
 ╚═════╝ 
1
 ██╗
███║
╚██║
 ██║
 ██║
 ╚═╝
2
██████╗ 
╚════██╗
 █████╔╝
██╔═══╝ 
███████╗
╚══════╝
3
██████╗ 
╚════██╗
 █████╔╝
 ╚═══██╗
██████╔╝
╚═════╝ 
4
██╗  ██╗
██║  ██║
███████║
╚════██║
     ██║
     ╚═╝
5
███████╗
██╔════╝
███████╗
╚════██║
███████║
╚══════╝
6
 ██████╗ 
██╔════╝ 
███████╗ 
██╔═══██╗
╚██████╔╝
 ╚═════╝ 
7
███████╗
╚════██║
    ██╔╝
   ██╔╝ 
   ██║  
   ╚═╝  
8
 █████╗ 
██╔══██╗
╚█████╔╝
██╔══██╗
╚█████╔╝
 ╚════╝ 
9
 █████╗ 
██╔══██╗
╚██████║
 ╚═══██║
 █████╔╝
 ╚════╝ 
SPACE
 
 
 
 
 
 
DOT
   
   
   
   
██╗
╚═╝
COMMA
   
   
   
   
▄█╗
╚═╝
BANG
██╗
██║
██║
╚═╝
██╗
╚═╝
QUES
██████╗ 
╚════██╗
  ▄███╔╝
  ▀▀══╝ 
  ██╗   
  ╚═╝   
DASH
      
      
      
      
█████╗
╚════╝
COLON
   
   
██╗
╚═╝
██╗
╚═╝
SEMI
   
   
██╗
╚═╝
▄█╗
▀═╝
APOS
 
 
 
 
 
 
AMP
   ██╗   
   ██║   
████████╗
██╔═██╔═╝
██████║  
╚═════╝  
FONTEOF
parse_font block 6 "$_FD"
IFS= read -r -d "" _FD <<'FONTEOF'
A
        
    ___ 
   /   |
  / /| |
 / ___ |
/_/  |_|
B
         
    ____ 
   / __ )
  / __  |
 / /_/ / 
/_____/  
C
         
   ______
  / ____/
 / /     
/ /___   
\____/   
D
         
    ____ 
   / __ \
  / / / /
 / /_/ / 
/_____/  
E
          
    ______
   / ____/
  / __/   
 / /___   
/_____/   
F
          
    ______
   / ____/
  / /_    
 / __/    
/_/       
G
         
   ______
  / ____/
 / / __  
/ /_/ /  
\____/   
H
          
    __  __
   / / / /
  / /_/ / 
 / __  /  
/_/ /_/   
I
        
    ____
   /  _/
   / /  
 _/ /   
/___/   
J
         
       __
      / /
 __  / / 
/ /_/ /  
\____/   
K
         
    __ __
   / //_/
  / ,<   
 / /| |  
/_/ |_|  
L
       
    __ 
   / / 
  / /  
 / /___
/_____/
M
           
    __  ___
   /  |/  /
  / /|_/ / 
 / /  / /  
/_/  /_/   
N
          
    _   __
   / | / /
  /  |/ / 
 / /|  /  
/_/ |_/   
O
        
   ____ 
  / __ \
 / / / /
/ /_/ / 
\____/  
P
         
    ____ 
   / __ \
  / /_/ /
 / ____/ 
/_/      
Q
        
   ____ 
  / __ \
 / / / /
/ /_/ / 
\___\_\ 
R
         
    ____ 
   / __ \
  / /_/ /
 / _, _/ 
/_/ |_|  
S
        
   _____
  / ___/
  \__ \ 
 ___/ / 
/____/  
T
        
  ______
 /_  __/
  / /   
 / /    
/_/     
U
         
   __  __
  / / / /
 / / / / 
/ /_/ /  
\____/   
V
        
 _    __
| |  / /
| | / / 
| |/ /  
|___/   
W
           
 _       __
| |     / /
| | /| / / 
| |/ |/ /  
|__/|__/   
X
        
   _  __
  | |/ /
  |   / 
 /   |  
/_/|_|  
Y
      
__  __
\ \/ /
 \  / 
 / /  
/_/   
Z
      
 _____
/__  /
  / / 
 / /__
/____/
0
        
   ____ 
  / __ \
 / / / /
/ /_/ / 
\____/  
1
      
   ___
  <  /
  / / 
 / /  
/_/   
2
       
   ___ 
  |__ \
  __/ /
 / __/ 
/____/ 
3
        
   _____
  |__  /
   /_ < 
 ___/ / 
/____/  
4
        
   __ __
  / // /
 / // /_
/__  __/
  /_/   
5
          
    ______
   / ____/
  /___ \  
 ____/ /  
/_____/   
6
        
   _____
  / ___/
 / __ \ 
/ /_/ / 
\____/  
7
      
 _____
/__  /
  / / 
 / /  
/_/   
8
        
   ____ 
  ( __ )
 / __  |
/ /_/ / 
\____/  
9
        
   ____ 
  / __ \
 / /_/ /
 \__, / 
/____/  
SPACE
 
 
 
 
 
 
DOT
   
   
   
   
 _ 
(_)
COMMA
   
   
   
 _ 
( )
|/ 
BANG
      
    __
   / /
  / / 
 /_/  
(_)   
QUES
      
  ___ 
 /__ \
  / _/
 /_/  
(_)   
DASH
       
       
       
       
 ______
/_____/
COLON
     
     
   _ 
  (_)
 _   
(_)  
SEMI
     
   _ 
  (_)
 _   
( )  
|/   
APOS
    
    
    
  _ 
 ( )
 |/ 
AMP
         
   ___   
  ( _ )  
 / __ \/|
/ /_/  < 
\____/\/ 
FONTEOF
parse_font slant 6 "$_FD"
IFS= read -r -d "" _FD <<'FONTEOF'
A
      ___     
     /\  \    
    /::\  \   
   /:/\:\  \  
  /::\~\:\  \ 
 /:/\:\ \:\__\
 \/__\:\/:/  /
      \::/  / 
      /:/  /  
     /:/  /   
     \/__/    
B
      ___     
     /\  \    
    /::\  \   
   /:/\:\  \  
  /::\~\:\__\ 
 /:/\:\ \:|__|
 \:\~\:\/:/  /
  \:\ \::/  / 
   \:\/:/  /  
    \::/__/   
     ~~       
C
      ___     
     /\  \    
    /::\  \   
   /:/\:\  \  
  /:/  \:\  \ 
 /:/__/ \:\__\
 \:\  \  \/__/
  \:\  \      
   \:\  \     
    \:\__\    
     \/__/    
D
      ___     
     /\  \    
    /::\  \   
   /:/\:\  \  
  /:/  \:\__\ 
 /:/__/ \:|__|
 \:\  \ /:/  /
  \:\  /:/  / 
   \:\/:/  /  
    \::/__/   
     ~~       
E
      ___     
     /\  \    
    /::\  \   
   /:/\:\  \  
  /::\~\:\  \ 
 /:/\:\ \:\__\
 \:\~\:\ \/__/
  \:\ \:\__\  
   \:\ \/__/  
    \:\__\    
     \/__/    
F
              
              
      ___     
     /\  \    
    /::\  \   
   /:/\:\  \  
  /::\~\:\  \ 
 /:/\:\ \:\__\
 \/__\:\ \/__/
      \:\__\  
       \/__/  
G
      ___     
     /\  \    
    /::\  \   
   /:/\:\  \  
  /:/  \:\  \ 
 /:/__/_\:\__\
 \:\  /\ \/__/
  \:\ \:\__\  
   \:\/:/  /  
    \::/  /   
     \/__/    
H
      ___     
     /\__\    
    /:/  /    
   /:/__/     
  /::\  \ ___ 
 /:/\:\  /\__\
 \/__\:\/:/  /
      \::/  / 
      /:/  /  
     /:/  /   
     \/__/    
I
            
            
      ___   
     /\  \  
     \:\  \ 
     /::\__\
  __/:/\/__/
 /\/:/  /   
 \::/__/    
  \:\__\    
   \/__/    
J
             
             
             
       ___   
      /\  \  
      \:\  \ 
  ___ /::\__\
 /\  /:/\/__/
 \:\/:/  /   
  \::/  /    
   \/__/     
K
      ___     
     /\__\    
    /:/  /    
   /:/__/     
  /::\__\____ 
 /:/\:::::\__\
 \/_|:|~~|~   
    |:|  |    
    |:|  |    
    |:|  |    
     \|__|    
L
      ___ 
     /\__\
    /:/  /
   /:/  / 
  /:/  /  
 /:/__/   
 \:\  \   
  \:\  \  
   \:\  \ 
    \:\__\
     \/__/
M
      ___     
     /\__\    
    /::|  |   
   /:|:|  |   
  /:/|:|__|__ 
 /:/ |::::\__\
 \/__/~~/:/  /
       /:/  / 
      /:/  /  
     /:/  /   
     \/__/    
N
      ___     
     /\__\    
    /::|  |   
   /:|:|  |   
  /:/|:|  |__ 
 /:/ |:| /\__\
 \/__|:|/:/  /
     |:/:/  / 
     |::/  /  
     /:/  /   
     \/__/    
O
      ___     
     /\  \    
    /::\  \   
   /:/\:\  \  
  /:/  \:\  \ 
 /:/__/ \:\__\
 \:\  \ /:/  /
  \:\  /:/  / 
   \:\/:/  /  
    \::/  /   
     \/__/    
P
              
              
      ___     
     /\  \    
    /::\  \   
   /:/\:\  \  
  /::\~\:\  \ 
 /:/\:\ \:\__\
 \/__\:\/:/  /
      \::/  / 
       \/__/  
Q
      ___     
     /\  \    
    /::\  \   
   /:/\:\  \  
   \:\~\:\  \ 
    \:\ \:\__\
     \:\/:/  /
      \::/  / 
      /:/  /  
     /:/  /   
     \/__/    
R
      ___     
     /\  \    
    /::\  \   
   /:/\:\  \  
  /::\~\:\  \ 
 /:/\:\ \:\__\
 \/_|::\/:/  /
    |:|::/  / 
    |:|\/__/  
    |:|  |    
     \|__|    
S
      ___     
     /\  \    
    /::\  \   
   /:/\ \  \  
  _\:\~\ \  \ 
 /\ \:\ \ \__\
 \:\ \:\ \/__/
  \:\ \:\__\  
   \:\/:/  /  
    \::/  /   
     \/__/    
T
              
              
      ___     
     /\  \    
     \:\  \   
      \:\  \  
      /::\  \ 
     /:/\:\__\
    /:/  \/__/
   /:/  /     
   \/__/      
U
      ___     
     /\__\    
    /:/  /    
   /:/  /     
  /:/  /  ___ 
 /:/__/  /\__\
 \:\  \ /:/  /
  \:\  /:/  / 
   \:\/:/  /  
    \::/  /   
     \/__/    
V
              
      ___     
     /\__\    
    /:/  /    
   /:/  /     
  /:/__/  ___ 
  |:|  | /\__\
  |:|  |/:/  /
  |:|__/:/  / 
   \::::/__/  
    ~~~~      
W
      ___     
     /\__\    
    /:/ _/_   
   /:/ /\__\  
  /:/ /:/ _/_ 
 /:/_/:/ /\__\
 \:\/:/ /:/  /
  \::/_/:/  / 
   \:\/:/  /  
    \::/  /   
     \/__/    
X
      ___     
     |\__\    
     |:|  |   
     |:|  |   
     |:|__|__ 
 ____/::::\__\
 \::::/~~/~   
  ~~|:|~~|    
    |:|  |    
    |:|  |    
     \|__|    
Y
              
              
      ___     
     |\__\    
     |:|  |   
     |:|  |   
     |:|__|__ 
     /::::\__\
    /:/~~/~   
   /:/  /     
   \/__/      
Z
      ___     
     /\  \    
     \:\  \   
      \:\  \  
       \:\  \ 
 _______\:\__\
 \::::::::/__/
  \:\~~\~~    
   \:\  \     
    \:\__\    
     \/__/    
0
 
 
 
 
 
 
 
 
 
 
 
1
 
 
 
 
 
 
 
 
 
 
 
2
 
 
 
 
 
 
 
 
 
 
 
3
 
 
 
 
 
 
 
 
 
 
 
4
 
 
 
 
 
 
 
 
 
 
 
5
 
 
 
 
 
 
 
 
 
 
 
6
 
 
 
 
 
 
 
 
 
 
 
7
 
 
 
 
 
 
 
 
 
 
 
8
 
 
 
 
 
 
 
 
 
 
 
9
 
 
 
 
 
 
 
 
 
 
 
SPACE
 
 
 
 
 
 
 
 
 
 
 
DOT
 
 
 
 
 
 
 
 
 
 
 
COMMA
 
 
 
 
 
 
 
 
 
 
 
BANG
 
 
 
 
 
 
 
 
 
 
 
QUES
 
 
 
 
 
 
 
 
 
 
 
DASH
 
 
 
 
 
 
 
 
 
 
 
COLON
 
 
 
 
 
 
 
 
 
 
 
SEMI
 
 
 
 
 
 
 
 
 
 
 
APOS
 
 
 
 
 
 
 
 
 
 
 
AMP
 
 
 
 
 
 
 
 
 
 
 
FONTEOF
parse_font iso 11 "$_FD"

# Active typeface: FONTKEY selects the font prefix into G; GLYPH_H its row height; the blank
# glyph (unknown chars) is GLYPH_H rows of one space.
FONTKEY=double; GLYPH_H=3; _blankglyph=" "
apply_typeface() {
    local name="$1"
    case $name in single|double|block|slant|iso) ;; *) name=double ;; esac
    FONTKEY=$name; GLYPH_H=${FONT_H[$name]}
    _blankglyph=" "; local _i; for (( _i=1; _i<GLYPH_H; _i++ )); do _blankglyph+=$'\n'" "; done
}
# Look up one glyph: REPLY = its rows (\n-joined), RW = its column width (first-row length).
glyph() {
    REPLY="${G[$FONTKEY$SEP$1]}"; [[ -z "$REPLY" ]] && REPLY="$_blankglyph"
    local _fr="${REPLY%%$'\n'*}"; RW=${#_fr}
}

# Randomize the typeface each reveal (default), or pin one via CODECK_TYPEFACE.
typeset -a FONTS; FONTS=(single double block slant iso)
_fixed_font="${CODECK_TYPEFACE:-double}"
[[ "$_fixed_font" == (single|double|block|slant|iso) ]] || _fixed_font=double
case "${CODECK_FONT_RANDOM:-true}" in false|0|no|off) FONT_RANDOM=0 ;; *) FONT_RANDOM=1 ;; esac
apply_typeface "$_fixed_font"

# Per-glyph placement, filled by layout_sentence and consumed by the reveal animator.
# One entry per drawable character (spaces are just gaps, not entries).
typeset -a UROW UX UGLYPH UWORD LW
n_units=0; _clipped=0
# Horizontal alignment of each line: center (default) | left | right.
ALIGN="${CODECK_ALIGN:-center}"
[[ "$ALIGN" == (left|right|center) ]] || ALIGN=center

# Word-wrap a sentence from the left margin and record every glyph's position — WITHOUT
# drawing anything. Whole glyphs only: a word that would overflow the line starts a fresh
# line rather than being split. Glyphs are GLYPH_H rows tall (varies by active typeface).
#
# The line PITCH adapts to the terminal height: GLYPH_H+1 (a blank row between lines) when
# there is room, tightening to GLYPH_H (lines touching) so long sentences still fit on short
# screens. The block is then VERTICALLY CENTRED from its own height — a one-line sentence
# lands mid-screen, a taller one is balanced top/bottom. Text uses the full screen (the
# screen is wiped before each reveal; header/footer only return during the pipe rest). Only
# if it can't fit even at the tight pitch is it clipped (and _clipped set, which
# choose_and_layout uses to prefer a sentence that fits whole). n_units==0 ⇒ nothing fit.
layout_sentence() {
    n_units=0; _clipped=0
    (( ROWS < GLYPH_H || COLS < 8 )) && return
    local -a words; words=( ${=1} )          # split on whitespace, collapse runs
    local left=1 wg=2 igap=1                   # left margin; word gap; inter-letter gap
    local line=0 x=$left lw=0 wi k wwidth add
    for (( wi=0; wi<${#words[@]}; wi++ )); do
        local w="${(U)words[wi]}"
        wwidth=0                               # measure the word first (for the wrap test)
        for (( k=0; k<${#w}; k++ )); do
            glyph "${w:$k:1}"                  # sets RW
            (( k > 0 )) && (( wwidth += igap ))
            (( wwidth += RW ))
        done
        (( wwidth < 1 )) && continue
        add=$wwidth; (( lw > 0 )) && add=$(( add + wg ))
        if (( lw > 0 && lw + add > COLS )); then          # wrap to a new line (no vertical cap yet)
            LW[line]=$lw                                  # finalise the just-filled line's width
            (( line++ )); lw=0; x=$left; add=$wwidth
        elif (( lw > 0 )); then
            x=$(( x + wg ))
        fi
        for (( k=0; k<${#w}; k++ )); do                   # place each glyph (row = line index for now)
            glyph "${w:$k:1}"                             # sets REPLY (rows) + RW
            (( k > 0 )) && (( x += igap ))
            UROW[n_units]=$line; UX[n_units]=$x
            UGLYPH[n_units]="$REPLY"; UWORD[n_units]=$wi
            (( x += RW )); (( n_units++ ))
        done
        lw=$(( lw + add ))
    done
    (( n_units == 0 )) && return
    LW[line]=$lw                                          # finalise the last line's width
    local nlines=$(( UROW[n_units - 1] + 1 ))
    local cap=$(( ROWS / GLYPH_H )); (( cap < 1 )) && cap=1   # capacity at tightest pitch (=GLYPH_H)
    if (( nlines > cap )); then
        _clipped=1; nlines=$cap
        while (( n_units > 0 && UROW[n_units - 1] >= nlines )); do (( n_units-- )); done
        (( n_units == 0 )) && return
    fi
    # Airy pitch (a blank row between lines) if it fits; otherwise tighten to touching.
    local pitch=$(( GLYPH_H + 1 ))
    (( nlines > 1 && (nlines - 1) * pitch + GLYPH_H > ROWS )) && pitch=$GLYPH_H
    # Convert stored line indices → absolute rows, centred on the block's own height.
    local total_h=$(( (nlines - 1) * pitch + GLYPH_H ))
    local top=$(( (ROWS - total_h) / 2 + 1 ))
    (( top + total_h - 1 > ROWS )) && top=$(( ROWS - total_h + 1 ))
    (( top < 1 )) && top=1
    # Also shift each glyph horizontally per its line's width (left/centre/right).
    local i ln off
    for (( i=0; i<n_units; i++ )); do
        ln=${UROW[i]}
        case $ALIGN in
            center) off=$(( (COLS - LW[ln]) / 2 )) ;;
            right)  off=$(( COLS - LW[ln] )) ;;
            *)      off=0 ;;
        esac
        (( off < 0 )) && off=0
        UX[i]=$(( UX[i] + off ))
        UROW[i]=$(( top + ln * pitch ))
    done
}

# SENTENCES is sorted ascending by length, so the ones that fit the current resolution
# form a prefix [0..fitmax]. Binary-search that cutoff (layout is pure string work — no
# I/O, no forks), then pick a random sentence from the fitting prefix. The short safety
# loop covers the rare case where a slightly shorter sentence still clips (wrapping isn't
# perfectly monotonic in length); if even that fails we fall back to the shortest.
choose_and_layout() {
    local n=${#SENTENCES[@]} lo=0 hi mid fitmax=-1 tries
    hi=$(( n - 1 ))
    while (( lo <= hi )); do
        mid=$(( (lo + hi) / 2 ))
        layout_sentence "${SENTENCES[mid]}"
        if (( n_units > 0 && ! _clipped )); then fitmax=$mid; lo=$(( mid + 1 ))
        else hi=$(( mid - 1 )); fi
    done
    (( fitmax < 0 )) && { layout_sentence "${SENTENCES[0]}"; return; }   # nothing fits — use shortest
    for (( tries = 0; tries < 5; tries++ )); do
        layout_sentence "${SENTENCES[$(( RANDOM % (fitmax + 1) ))]}"
        (( n_units > 0 && ! _clipped )) && return
    done
    layout_sentence "${SENTENCES[0]}"
}

# Draw one placed glyph (GLYPH_H rows) in the bright shade.
blit_unit() {
    local i=$1 r
    local -a rr=( "${(@f)UGLYPH[i]}" )
    printf '%s%s' "$BOLD" "$C1"
    for (( r=0; r<${#rr[@]}; r++ )); do
        printf '\033[%d;%dH%s' "$(( UROW[i] + r ))" "${UX[i]}" "${rr[r]}"
    done
    printf '%s' "$RS"
}

# Inter-step delay during a reveal — forks nothing and keeps draining input so q quits.
anim_wait() {
    local cs=$1; (( cs < 1 )) && cs=1
    if (( HAVE_ZSELECT )); then zselect -t $cs -r 0 2>/dev/null && drain_input
    else sleep "0.$(printf '%02d' $cs)"; fi
}

# Reveal the laid-out glyphs progressively.
#   mode : 0 = one glyph at a time, 1 = one whole word at a time
#   base : delay per step in centiseconds (the "speed")
#   stag : 0 = linear (constant delay), 1 = staggered (jitter around base)
animate_reveal() {
    local mode=$1 base=$2 stag=$3 i cs
    printf '\033[?25l'
    for (( i=0; i<n_units; i++ )); do
        blit_unit $i
        # In word mode, don't pause until we've drawn the last glyph of the word.
        (( mode )) && (( i + 1 < n_units && UWORD[i+1] == UWORD[i] )) && continue
        cs=$base; (( stag )) && cs=$(( base / 2 + RANDOM % (base + 1) ))
        anim_wait $cs
        (( _quit )) && return
    done
}

# Per-step speeds (centiseconds) picked at random each cycle. Char mode has many more
# steps than word mode, so its per-step delays are smaller.
typeset -a CHAR_SPEEDS WORD_SPEEDS
CHAR_SPEEDS=(2 4 7)
WORD_SPEEDS=(10 18 28)

# Freeze for ~ms while STILL draining input (so q quits and notify banners land),
# in ≤0.3s chunks. Pipes are not stepped here — that's the readable pause.
hold_pause() {
    local left=$(( $1 / 10 )) chunk
    while (( left > 0 )); do
        chunk=$(( left > 30 ? 30 : left ))
        if (( HAVE_ZSELECT )); then zselect -t $chunk -r 0 2>/dev/null && drain_input
        else sleep "0.$(printf '%02d' $chunk)"; fi
        (( _quit )) && return
        (( left -= chunk ))
    done
}

# ── Main ────────────────────────────────────────────────────────────────────
get_size

# Splash: enter alt-screen, show the centred name briefly so libghostty's
# SET_TITLE lands before the animation floods the PTY.
# 344 (BACKLOG 344.B1) — the EXPLICIT `\e[?1049h` alongside `tput smcup`: smcup is a
# terminfo lookup that can silently no-op under an unknown TERM, and the alternate screen
# is now LOAD-BEARING for terminal-history capture — the streaming capture filter
# (TerminalTurnCapture) drops alt-screen bytes, which is exactly what keeps saver frames
# from flooding the bounded history window. Emitting the escape directly makes that
# guarantee terminfo-independent (a second 1049h after smcup is a no-op).
tput smcup 2>/dev/null; printf '\033[?1049h'; tput civis 2>/dev/null
printf '\033[2J\033[H'
_slbl="  ${WS_NAME}  "; _sx=$(( (COLS - ${#_slbl}) / 2 + 1 )); (( _sx < 1 )) && _sx=1
printf '\033[%d;%dH%s%s%s%s' "$(( ROWS / 2 ))" "$_sx" "$BOLD" "$C1" "$_slbl" "$RS"
if (( HAVE_ZSELECT )); then zselect -t $(( SPLASH_MS / 10 )) -r 0 2>/dev/null; else sleep 0.4; fi

stty -echo -icanon min 0 time 0 2>/dev/null
printf '\033[2J\033[H'
get_size
for i in 0 1 2 3; do new_pipe; done
flash_fill
draw_ui
_since_word=0

while true; do
    if (( _resized )); then
        _resized=0; N=0; _since_word=0
        printf '\033[2J\033[H'
        local _msg=" ${COLS}×${ROWS} " _mx
        _mx=$(( (COLS - ${#_msg}) / 2 + 1 )); (( _mx < 1 )) && _mx=1
        printf '\033[%d;%dH%s%s%s%s' "$(( ROWS / 2 ))" "$_mx" "$BOLD" "$C1" "$_msg" "$RS"
        if (( HAVE_ZSELECT )); then zselect -t 60 -r 0 2>/dev/null; else sleep 0.6; fi
        printf '\033[2J\033[H'
        for i in 0 1 2 3; do new_pipe; done
        flash_fill
        draw_ui
    fi

    for (( i=0; i<N; i++ )); do step_pipe "$i"; done
    printf '\033[?25l%s' "$RS"     # keep cursor hidden
    frame_wait                     # frame delay + drain injected input (may set _quit / show a banner)
    (( _quit )) && break
    if (( _notify_ticks > 0 )); then    # keep the notification bar on top of the moving pipes
        draw_notify
        (( _notify_ticks-- ))
        (( _notify_ticks == 0 )) && clear_notify
    fi
    (( _frame++ ))
    # Sentence cycle: pipes run for WORD_EVERY frames (drifting over the previous, held
    # sentence), then — right before the next one — a blackout+flash floods the screen
    # with a fresh pipe field (completely covering the old text), a random sentence is
    # laid out and ANIMATED in over it with a randomized technique/speed, and it's held a
    # few seconds to read. Header/footer return for the rest interval. Then repeat.
    (( _since_word++ ))
    if (( _since_word >= WORD_EVERY )); then
        _since_word=0
        blackout_flash              # pipe-flash transition that fully covers the old sentence
        (( FONT_RANDOM )) && apply_typeface "${FONTS[$(( RANDOM % ${#FONTS[@]} ))]}"
        choose_and_layout           # full-screen typography — no chrome during the reveal
        if (( n_units > 0 )); then
            local _mode=$(( RANDOM % 2 )) _stag=$(( RANDOM % 2 )) _base
            if (( _mode )); then _base=${WORD_SPEEDS[$(( RANDOM % ${#WORD_SPEEDS[@]} ))]}
            else                 _base=${CHAR_SPEEDS[$(( RANDOM % ${#CHAR_SPEEDS[@]} ))]}; fi
            animate_reveal $_mode $_base $_stag
            (( _quit )) && break
            hold_pause "$WORD_HOLD_MS"
            (( _quit )) && break
        fi
        draw_ui                     # header/footer return while pipes drift over the text
    fi
    if (( _winch )) || (( _frame % POLL_EVERY == 0 )); then
        _winch=0
        maybe_resize
        poll_ctrl       # live retune (e.g. speed) from the app's control file
    fi
done
cleanup
