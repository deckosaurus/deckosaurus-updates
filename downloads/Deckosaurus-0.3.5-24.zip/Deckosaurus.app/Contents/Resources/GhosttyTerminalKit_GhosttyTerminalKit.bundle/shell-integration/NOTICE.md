# Third-party notice — Ghostty shell integration

This directory is vendored from upstream projects and is **not** covered by the
repository's MIT licence (`../../../LICENSE`). Each file below is distributed
under the licence stated for it, unchanged.

Upstream: [ghostty-org/ghostty](https://github.com/ghostty-org/ghostty) —
`src/shell-integration/`. Ghostty itself is MIT-licensed, with per-file
exceptions for the Kitty-derived scripts; this notice mirrors those exceptions.

| File | Licence | Origin |
|---|---|---|
| `bash/ghostty.bash` | **GPL-3.0-or-later** | ghostty-org/ghostty; parts based on [Kitty](https://github.com/kovidgoyal/kitty)'s bash integration (GPLv3) |
| `zsh/.zshenv` | **GPL-3.0-or-later** | ghostty-org/ghostty; started as a copy of Kitty's zsh integration (GPLv3) |
| `zsh/ghostty-integration` | **GPL-3.0-or-later** | ghostty-org/ghostty; started as a copy of Kitty's zsh integration (GPLv3) |
| `bash/bash-preexec.sh` | MIT | [rcaloras/bash-preexec](https://github.com/rcaloras/bash-preexec) v0.6.0 — Copyright (c) 2017 Ryan Caloras and contributors (forked from Glyph Lefkowitz) |
| `fish/vendor_conf.d/ghostty-shell-integration.fish` | MIT | ghostty-org/ghostty (no Kitty-derived content; carries no GPL header) |

## The GPLv3 exception

The three files marked **GPL-3.0-or-later** above are derived from Kitty, which
is distributed under the GNU General Public License version 3. Each of them
carries that statement in its own header comment. They are redistributed here
**verbatim and under the GPLv3**, whose full text is in
[`LICENSE.GPL-3.0`](LICENSE.GPL-3.0) in this directory. They are **not** covered
by this repository's MIT licence, they have not been relicensed, and they must
not be relicensed by anything that vendors this directory onward.

These scripts are shell snippets sourced by the user's own shell at runtime;
they are shipped as resources inside the application bundle
(`Contents/Resources/ghostty/shell-integration/`, copied wholesale by
`Scripts/assemble-bundle.sh`) and are never compiled or linked into the
application binary.
